{
    'name': 'Gate & Turnstile Management',
    'version': '1.0.4',
    'summary': 'NFC Gate Access and Turnstile Device Management',
    'author': 'Developer',
    'depends': ['base', 'hr', 'hr_attendance', 'web'],
    'data': [
        'security/ir.model.access.csv',
        'views/gate_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'nfc_gate_access/static/src/js/card_writer.js',
        ],
    },
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
