from odoo import models, fields

class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    nfc_card_id = fields.Char(string='NFC Kart UUID')