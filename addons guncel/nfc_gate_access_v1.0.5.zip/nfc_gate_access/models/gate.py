from odoo import models, fields

class NfcGate(models.Model):
    _name = 'nfc.gate'
    _description = 'Turnike ve Kapi Yonetimi'

    name = fields.Char(string='Kapi Adi', required=True)
    code = fields.Char(string='Kapi Kodu (ID)', required=True)
    active = fields.Boolean(string='Aktif', default=True)
    
    allowed_employee_ids = fields.Many2many(
        'hr.employee',
        'nfc_gate_employee_rel',
        'gate_id',
        'employee_id',
        string='Yetkili Personeller'
    )


class HrEmployeeGateExtension(models.Model):
    _inherit = 'hr.employee'

    locked_device_id = fields.Char(
        string='Kayıtlı Cihaz ID',
        help='Ilk aktivasyonda kilitlenen telefon donanim UUID kimligi.'
    )
    nfc_card_id = fields.Char(
        string='NFC Kart UUID',
        help='Personelin tanimli NFC kart kimligi.'
    )

    def action_reset_device_lock(self):
        """Telefon degisikliginde cihaz kilidini sifirlar"""
        for emp in self:
            emp.locked_device_id = False
